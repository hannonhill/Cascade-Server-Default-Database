-- MySQL dump 10.13  Distrib 5.1.35, for apple-darwin9.5.0 (i386)
--
-- Host: localhost    Database: cascade
-- ------------------------------------------------------
-- Server version	5.1.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DATABASECHANGELOG`
--

DROP TABLE IF EXISTS `DATABASECHANGELOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOG` (
  `ID` varchar(63) COLLATE utf8_unicode_ci NOT NULL,
  `AUTHOR` varchar(63) COLLATE utf8_unicode_ci NOT NULL,
  `FILENAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `DATEEXECUTED` datetime NOT NULL,
  `MD5SUM` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `COMMENTS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TAG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LIQUIBASE` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`,`AUTHOR`,`FILENAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOG`
--

LOCK TABLES `DATABASECHANGELOG` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `DATABASECHANGELOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DATABASECHANGELOGLOCK`
--

DROP TABLE IF EXISTS `DATABASECHANGELOGLOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DATABASECHANGELOGLOCK` (
  `ID` int(11) NOT NULL,
  `LOCKED` tinyint(1) NOT NULL,
  `LOCKGRANTED` datetime DEFAULT NULL,
  `LOCKEDBY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DATABASECHANGELOGLOCK`
--

LOCK TABLES `DATABASECHANGELOGLOCK` WRITE;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DATABASECHANGELOGLOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_BLOB_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_BLOB_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_BLOB_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `TRIGGER_NAME` (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_BLOB_TRIGGERS_ibfk_1` FOREIGN KEY (`TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_BLOB_TRIGGERS`
--

LOCK TABLES `QRTZ_BLOB_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_BLOB_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_BLOB_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_CALENDARS`
--

DROP TABLE IF EXISTS `QRTZ_CALENDARS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_CALENDARS` (
  `CALENDAR_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_CALENDARS`
--

LOCK TABLES `QRTZ_CALENDARS` WRITE;
/*!40000 ALTER TABLE `QRTZ_CALENDARS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_CALENDARS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_CRON_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_CRON_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_CRON_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `CRON_EXPRESSION` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TIME_ZONE_ID` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `TRIGGER_NAME` (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_CRON_TRIGGERS_ibfk_1` FOREIGN KEY (`TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_CRON_TRIGGERS`
--

LOCK TABLES `QRTZ_CRON_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_CRON_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_CRON_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_FIRED_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_FIRED_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_FIRED_TRIGGERS` (
  `ENTRY_ID` varchar(95) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `IS_VOLATILE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `INSTANCE_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `FIRED_TIME` bigint(13) NOT NULL,
  `STATE` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IS_STATEFUL` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PRIORITY` int(11) NOT NULL,
  PRIMARY KEY (`ENTRY_ID`),
  KEY `idx_qrtz_ft_trig_name` (`TRIGGER_NAME`),
  KEY `idx_qrtz_ft_trig_group` (`TRIGGER_GROUP`),
  KEY `idx_qrtz_ft_trig_n_g` (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `idx_qrtz_ft_trig_inst_name` (`INSTANCE_NAME`),
  KEY `idx_qrtz_ft_job_name` (`JOB_NAME`),
  KEY `idx_qrtz_ft_job_group` (`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_FIRED_TRIGGERS`
--

LOCK TABLES `QRTZ_FIRED_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_FIRED_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_FIRED_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_JOB_DETAILS`
--

DROP TABLE IF EXISTS `QRTZ_JOB_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_JOB_DETAILS` (
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `IS_DURABLE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `IS_VOLATILE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `IS_STATEFUL` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_JOB_DETAILS`
--

LOCK TABLES `QRTZ_JOB_DETAILS` WRITE;
/*!40000 ALTER TABLE `QRTZ_JOB_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_JOB_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_JOB_LISTENERS`
--

DROP TABLE IF EXISTS `QRTZ_JOB_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_JOB_LISTENERS` (
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_LISTENER` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`JOB_NAME`,`JOB_GROUP`,`JOB_LISTENER`),
  KEY `JOB_NAME` (`JOB_NAME`,`JOB_GROUP`),
  CONSTRAINT `QRTZ_JOB_LISTENERS_ibfk_1` FOREIGN KEY (`JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_JOB_LISTENERS`
--

LOCK TABLES `QRTZ_JOB_LISTENERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_JOB_LISTENERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_JOB_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_LOCKS`
--

DROP TABLE IF EXISTS `QRTZ_LOCKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_LOCKS` (
  `LOCK_NAME` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_LOCKS`
--

LOCK TABLES `QRTZ_LOCKS` WRITE;
/*!40000 ALTER TABLE `QRTZ_LOCKS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_LOCKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_PAUSED_TRIGGER_GRPS`
--

DROP TABLE IF EXISTS `QRTZ_PAUSED_TRIGGER_GRPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_PAUSED_TRIGGER_GRPS` (
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_PAUSED_TRIGGER_GRPS`
--

LOCK TABLES `QRTZ_PAUSED_TRIGGER_GRPS` WRITE;
/*!40000 ALTER TABLE `QRTZ_PAUSED_TRIGGER_GRPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_PAUSED_TRIGGER_GRPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SCHEDULER_STATE`
--

DROP TABLE IF EXISTS `QRTZ_SCHEDULER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_SCHEDULER_STATE` (
  `INSTANCE_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `LAST_CHECKIN_TIME` bigint(13) NOT NULL,
  `CHECKIN_INTERVAL` bigint(13) NOT NULL,
  `RECOVERER` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SCHEDULER_STATE`
--

LOCK TABLES `QRTZ_SCHEDULER_STATE` WRITE;
/*!40000 ALTER TABLE `QRTZ_SCHEDULER_STATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_SCHEDULER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SIMPLE_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_SIMPLE_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_SIMPLE_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `REPEAT_COUNT` bigint(7) NOT NULL,
  `REPEAT_INTERVAL` bigint(12) NOT NULL,
  `TIMES_TRIGGERED` bigint(7) NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `TRIGGER_NAME` (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_SIMPLE_TRIGGERS_ibfk_1` FOREIGN KEY (`TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SIMPLE_TRIGGERS`
--

LOCK TABLES `QRTZ_SIMPLE_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_SIMPLE_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_SIMPLE_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_TRIGGERS` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `JOB_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `IS_VOLATILE` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint(13) DEFAULT NULL,
  `PREV_FIRE_TIME` bigint(13) DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_TYPE` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `START_TIME` bigint(13) NOT NULL,
  `END_TIME` bigint(13) DEFAULT NULL,
  `CALENDAR_NAME` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MISFIRE_INSTR` smallint(2) DEFAULT NULL,
  `JOB_DATA` blob,
  `PRIORITY` int(11) DEFAULT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `JOB_NAME` (`JOB_NAME`,`JOB_GROUP`),
  KEY `idx_qrtz_t_next_fire_time` (`NEXT_FIRE_TIME`),
  KEY `idx_qrtz_t_state` (`TRIGGER_STATE`),
  KEY `idx_qrtz_t_nf_st` (`TRIGGER_STATE`,`NEXT_FIRE_TIME`),
  CONSTRAINT `QRTZ_TRIGGERS_ibfk_1` FOREIGN KEY (`JOB_NAME`, `JOB_GROUP`) REFERENCES `qrtz_job_details` (`JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_TRIGGERS`
--

LOCK TABLES `QRTZ_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_TRIGGER_LISTENERS`
--

DROP TABLE IF EXISTS `QRTZ_TRIGGER_LISTENERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QRTZ_TRIGGER_LISTENERS` (
  `TRIGGER_NAME` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_GROUP` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `TRIGGER_LISTENER` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_LISTENER`),
  KEY `TRIGGER_NAME` (`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `QRTZ_TRIGGER_LISTENERS_ibfk_1` FOREIGN KEY (`TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `qrtz_triggers` (`TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_TRIGGER_LISTENERS`
--

LOCK TABLES `QRTZ_TRIGGER_LISTENERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_TRIGGER_LISTENERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_TRIGGER_LISTENERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_aclentry`
--

DROP TABLE IF EXISTS `cxml_aclentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_aclentry` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `userName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userPermissionsLevel` tinyint(3) unsigned DEFAULT NULL,
  `groupName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupPermissionsLevel` tinyint(3) unsigned DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ACL_GROUP` (`groupName`),
  KEY `FK_ACL_PERMISSIONS` (`permissionsId`),
  KEY `FK_ACL_USER` (`userName`),
  CONSTRAINT `FK_ACL_GROUP` FOREIGN KEY (`groupName`) REFERENCES `cxml_group` (`name`) ON DELETE SET NULL,
  CONSTRAINT `FK_ACL_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`),
  CONSTRAINT `FK_ACL_USER` FOREIGN KEY (`userName`) REFERENCES `cxml_user` (`userName`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_aclentry`
--

LOCK TABLES `cxml_aclentry` WRITE;
/*!40000 ALTER TABLE `cxml_aclentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_aclentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_assetfactory`
--

DROP TABLE IF EXISTS `cxml_assetfactory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_assetfactory` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assetType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowSubfolder` tinyint(4) NOT NULL DEFAULT '0',
  `workflowMode` int(11) NOT NULL DEFAULT '3',
  `placementFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workflowDefinitionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups` text COLLATE utf8_unicode_ci,
  `folderPlacementPosition` bigint(20) DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `overwrite` tinyint(4) NOT NULL DEFAULT '0',
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `baseAssetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_AF_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_AF_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_AF_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_AF_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_AF_LOCK` (`lockId`),
  KEY `FK_AF_PLACEMENTFOLDER` (`placementFolderId`),
  KEY `FK_AF_BASEASSET` (`baseAssetId`),
  KEY `FK_AF_WORKFLOWDEF` (`workflowDefinitionId`),
  KEY `FK_AF_CONTAINER` (`containerId`),
  KEY `IDX_AF_PATH` (`path`),
  KEY `FK_AF_SITE` (`siteId`),
  CONSTRAINT `FK_AF_BASEASSET` FOREIGN KEY (`baseAssetId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AF_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_assetfactorycontainer` (`id`),
  CONSTRAINT `FK_AF_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AF_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_AF_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_assetfactory` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AF_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AF_PLACEMENTFOLDER` FOREIGN KEY (`placementFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AF_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_assetfactory` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AF_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_AF_WORKFLOWDEF` FOREIGN KEY (`workflowDefinitionId`) REFERENCES `cxml_workflowdefinition` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_assetfactory`
--

LOCK TABLES `cxml_assetfactory` WRITE;
/*!40000 ALTER TABLE `cxml_assetfactory` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_assetfactory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_assetfactorycontainer`
--

DROP TABLE IF EXISTS `cxml_assetfactorycontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_assetfactorycontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups` text COLLATE utf8_unicode_ci,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_AFC_LOCK` (`lockId`),
  UNIQUE KEY `UQ_AFC_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_AFC_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_AFC_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_AFC_NEXTVERSION` (`nextVersionId`),
  KEY `FK_AFC_CONTAINER` (`containerId`),
  KEY `IDX_AFC_PATH` (`path`),
  KEY `FK_AFC_SITE` (`siteId`),
  KEY `IDX_AFC_CONTAINER` (`containerId`),
  CONSTRAINT `FK_AFC_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_assetfactorycontainer` (`id`),
  CONSTRAINT `FK_AFC_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`),
  CONSTRAINT `FK_AFC_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AFC_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_assetfactory` (`id`),
  CONSTRAINT `FK_AFC_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AFC_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_assetfactorycontainer` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_AFC_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_assetfactorycontainer`
--

LOCK TABLES `cxml_assetfactorycontainer` WRITE;
/*!40000 ALTER TABLE `cxml_assetfactorycontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_assetfactorycontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_assetfactoryplugin`
--

DROP TABLE IF EXISTS `cxml_assetfactoryplugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_assetfactoryplugin` (
  `assetFactoryId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `pluginClass` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`assetFactoryId`,`pluginClass`),
  CONSTRAINT `FK_AFP_FACTORY` FOREIGN KEY (`assetFactoryId`) REFERENCES `cxml_assetfactory` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_assetfactoryplugin`
--

LOCK TABLES `cxml_assetfactoryplugin` WRITE;
/*!40000 ALTER TABLE `cxml_assetfactoryplugin` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_assetfactoryplugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_assetfactorypluginparam`
--

DROP TABLE IF EXISTS `cxml_assetfactorypluginparam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_assetfactorypluginparam` (
  `assetFactoryId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `pluginClass` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `paramName` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `paramValue` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  KEY `IDX_AFPP_FACTORY_CLASS` (`assetFactoryId`,`pluginClass`),
  CONSTRAINT `FK_AFPP_FACTORY` FOREIGN KEY (`assetFactoryId`) REFERENCES `cxml_assetfactory` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_assetfactorypluginparam`
--

LOCK TABLES `cxml_assetfactorypluginparam` WRITE;
/*!40000 ALTER TABLE `cxml_assetfactorypluginparam` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_assetfactorypluginparam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_audit`
--

DROP TABLE IF EXISTS `cxml_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_audit` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `tstamp` bigint(20) NOT NULL DEFAULT '0',
  `username` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entityId` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entityType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `information` text COLLATE utf8_unicode_ci,
  `version` tinyint(4) unsigned NOT NULL DEFAULT '2',
  `arg0` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `arg1` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `arg2` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `arg3` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `arg4` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userComment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `IDX_AUDIT_USERNAME` (`username`),
  KEY `IDX_AUDIT_ENTITY` (`entityId`),
  KEY `IDX_AUDIT_TSTAMP` (`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_audit`
--

LOCK TABLES `cxml_audit` WRITE;
/*!40000 ALTER TABLE `cxml_audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_blob`
--

DROP TABLE IF EXISTS `cxml_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_blob` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `data` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_blob`
--

LOCK TABLES `cxml_blob` WRITE;
/*!40000 ALTER TABLE `cxml_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_con_page_mapping`
--

DROP TABLE IF EXISTS `cxml_con_page_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_con_page_mapping` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `connectorId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreignId` text COLLATE utf8_unicode_ci,
  `creationDate` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_MAPPING_CON_PAGE` (`connectorId`,`pageId`),
  KEY `IDX_CON_PAGE_MAP_CON` (`connectorId`),
  KEY `IDX_CON_PAGE_MAP_PAGE` (`pageId`),
  CONSTRAINT `FK_CON_PAGE_MAP_CON` FOREIGN KEY (`connectorId`) REFERENCES `cxml_connector` (`id`),
  CONSTRAINT `FK_CON_PAGE_MAP_PAGE` FOREIGN KEY (`pageId`) REFERENCES `cxml_foldercontent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_con_page_mapping`
--

LOCK TABLES `cxml_con_page_mapping` WRITE;
/*!40000 ALTER TABLE `cxml_con_page_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_con_page_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_condexec`
--

DROP TABLE IF EXISTS `cxml_condexec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_condexec` (
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_condexec`
--

LOCK TABLES `cxml_condexec` WRITE;
/*!40000 ALTER TABLE `cxml_condexec` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_condexec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_configurationfile`
--

DROP TABLE IF EXISTS `cxml_configurationfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_configurationfile` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_CFGFILE_TYPE` (`type`),
  UNIQUE KEY `UQ_CFGFILE_METADATA` (`metadataId`),
  CONSTRAINT `FK_CFGFILE_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_configurationfile`
--

LOCK TABLES `cxml_configurationfile` WRITE;
/*!40000 ALTER TABLE `cxml_configurationfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_configurationfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_conn_ctype_link_param`
--

DROP TABLE IF EXISTS `cxml_conn_ctype_link_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_conn_ctype_link_param` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `paramName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paramValue` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `connCtypeLinkId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_CONNCTYPELINKPARAM_LINK` (`connCtypeLinkId`),
  CONSTRAINT `FK_CONNCTYPELINKPARAM_LINK` FOREIGN KEY (`connCtypeLinkId`) REFERENCES `cxml_connector_ctype_link` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_conn_ctype_link_param`
--

LOCK TABLES `cxml_conn_ctype_link_param` WRITE;
/*!40000 ALTER TABLE `cxml_conn_ctype_link_param` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_conn_ctype_link_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_connector`
--

DROP TABLE IF EXISTS `cxml_connector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_connector` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth1` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth2` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8_unicode_ci,
  `isVerified` tinyint(1) DEFAULT NULL,
  `connectorType` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apiType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destinationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `verifiedDate` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_CONNECTOR_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_CONNECTOR_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_CONNECTOR_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_CONNECTOR_LOCK` (`lockId`),
  UNIQUE KEY `UQ_CONNECTOR_METADATA` (`metadataId`),
  KEY `IDX_CONNECTOR_DEST` (`destinationId`),
  KEY `IDX_CONNECTOR_CONTAINER` (`containerId`),
  KEY `IDX_CONNECTOR_PATH` (`path`),
  CONSTRAINT `FK_CONNECTOR_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_connectorcontainer` (`id`),
  CONSTRAINT `FK_CONNECTOR_DEST` FOREIGN KEY (`destinationId`) REFERENCES `cxml_destination` (`id`),
  CONSTRAINT `FK_CONNECTOR_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CONNECTOR_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_CONNECTOR_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_connector` (`id`),
  CONSTRAINT `FK_CONNECTOR_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CONNECTOR_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_connector` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_connector`
--

LOCK TABLES `cxml_connector` WRITE;
/*!40000 ALTER TABLE `cxml_connector` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_connector` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_connector_ctype_link`
--

DROP TABLE IF EXISTS `cxml_connector_ctype_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_connector_ctype_link` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `connectorId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contentTypeId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageConfigurationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_CONCTYPELINK_CONNECTOR` (`connectorId`),
  KEY `FK_CONNCTYPELINK_CTYPE` (`contentTypeId`),
  KEY `FK_CONNCTYPELINK_PC` (`pageConfigurationId`),
  CONSTRAINT `FK_CONNCTYPELINK_PC` FOREIGN KEY (`pageConfigurationId`) REFERENCES `cxml_pageconfiguration` (`id`),
  CONSTRAINT `FK_CONCTYPELINK_CONNECTOR` FOREIGN KEY (`connectorId`) REFERENCES `cxml_connector` (`id`),
  CONSTRAINT `FK_CONNCTYPELINK_CTYPE` FOREIGN KEY (`contentTypeId`) REFERENCES `cxml_contenttype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_connector_ctype_link`
--

LOCK TABLES `cxml_connector_ctype_link` WRITE;
/*!40000 ALTER TABLE `cxml_connector_ctype_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_connector_ctype_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_connectorcontainer`
--

DROP TABLE IF EXISTS `cxml_connectorcontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_connectorcontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) DEFAULT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_CONCONT_PERMS` (`permissionsId`),
  UNIQUE KEY `UQ_CONCONT_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_CONCONT_PREV_VERS` (`prevVersionId`),
  UNIQUE KEY `UQ_CONCONT_NEXT_VERS` (`nextVersionId`),
  UNIQUE KEY `UQ_CONCONT_LOCK` (`lockId`),
  KEY `IDX_CONCONT_CONTAINER` (`containerId`),
  KEY `IDX_CONCONT_SITE` (`siteId`),
  KEY `IDX_CONCONT_PATH` (`path`),
  CONSTRAINT `FK_CONCONT_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_connectorcontainer` (`id`),
  CONSTRAINT `FK_CONCONT_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CONCONT_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_CONCONT_NEXTVERS` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_connectorcontainer` (`id`),
  CONSTRAINT `FK_CONCONT_PERMS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CONCONT_PREVVERS` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_connectorcontainer` (`id`),
  CONSTRAINT `FK_CONCONT_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_connectorcontainer`
--

LOCK TABLES `cxml_connectorcontainer` WRITE;
/*!40000 ALTER TABLE `cxml_connectorcontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_connectorcontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_connectorparameter`
--

DROP TABLE IF EXISTS `cxml_connectorparameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_connectorparameter` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `connectorId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paramName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paramValue` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isHidden` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CON_PARAM_CONID` (`connectorId`),
  CONSTRAINT `FK_CONPARAM_CONNECTOR` FOREIGN KEY (`connectorId`) REFERENCES `cxml_connector` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_connectorparameter`
--

LOCK TABLES `cxml_connectorparameter` WRITE;
/*!40000 ALTER TABLE `cxml_connectorparameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_connectorparameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_contenttype`
--

DROP TABLE IF EXISTS `cxml_contenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_contenttype` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageConfigurationSetId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `metadataSetId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `structuredDataDefinitionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_CTYPE_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_CTYPE_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_CTYPE_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_CTYPE_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_CTYPE_LOCK` (`lockId`),
  KEY `FK_CTYPE_PAGECONFIGSET` (`pageConfigurationSetId`),
  KEY `FK_CTYPE_CONTAINER` (`containerId`),
  KEY `FK_CTYPE_DATADEF` (`structuredDataDefinitionId`),
  KEY `FK_CTYPE_METASET` (`metadataSetId`),
  KEY `FK_CTYPE_SITE` (`siteId`),
  KEY `IDX_CTYPE_PATH` (`path`),
  CONSTRAINT `FK_CTYPE_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_contenttypecontainer` (`id`),
  CONSTRAINT `FK_CTYPE_DATADEF` FOREIGN KEY (`structuredDataDefinitionId`) REFERENCES `cxml_structureddatadefinition` (`id`),
  CONSTRAINT `FK_CTYPE_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CTYPE_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_CTYPE_METASET` FOREIGN KEY (`metadataSetId`) REFERENCES `cxml_metadataset` (`id`),
  CONSTRAINT `FK_CTYPE_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_contenttype` (`id`),
  CONSTRAINT `FK_CTYPE_PAGECONFIGSET` FOREIGN KEY (`pageConfigurationSetId`) REFERENCES `cxml_pageconfigurationset` (`id`),
  CONSTRAINT `FK_CTYPE_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CTYPE_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_contenttype` (`id`),
  CONSTRAINT `FK_CTYPE_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_contenttype`
--

LOCK TABLES `cxml_contenttype` WRITE;
/*!40000 ALTER TABLE `cxml_contenttype` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_contenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_contenttypecontainer`
--

DROP TABLE IF EXISTS `cxml_contenttypecontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_contenttypecontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_CTYPECONTAINER_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_CTYPE_CONTAINER_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_CTYPE_CONTAINER_LOCK` (`lockId`),
  UNIQUE KEY `UQ_CTYPE_CONTAINER_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_CTYPECONTAINER_METADATA` (`metadataId`),
  KEY `FK_CTYPE_CONTAINER_CONTAINER` (`containerId`),
  KEY `FK_CTYPE_CONTAINER_SITE` (`siteId`),
  KEY `IDX_CTYPECONTAINER_PATH` (`path`),
  CONSTRAINT `FK_CTYPECONTAINER_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_CTYPECONTAINER_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CTYPE_CONTAINER_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_contenttypecontainer` (`id`),
  CONSTRAINT `FK_CTYPE_CONTAINER_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_CTYPE_CONTAINER_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_contenttypecontainer` (`id`),
  CONSTRAINT `FK_CTYPE_CONTAINER_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_contenttypecontainer` (`id`),
  CONSTRAINT `FK_CTYPE_CONTAINER_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_contenttypecontainer`
--

LOCK TABLES `cxml_contenttypecontainer` WRITE;
/*!40000 ALTER TABLE `cxml_contenttypecontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_contenttypecontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_dbpub_entity`
--

DROP TABLE IF EXISTS `cxml_dbpub_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_dbpub_entity` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `assetType` int(11) NOT NULL,
  `accountId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `cmsId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `folderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `displayName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `teaser` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `author` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reviewDate` bigint(20) DEFAULT NULL,
  `startDate` bigint(20) DEFAULT NULL,
  `endDate` bigint(20) DEFAULT NULL,
  `lastPublishedAt` bigint(20) DEFAULT NULL,
  `lastPublishedBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdAt` bigint(20) DEFAULT NULL,
  `updatedBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updatedAt` bigint(20) DEFAULT NULL,
  `destinationId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DBPUB_ENTITY_DESTINATION` (`destinationId`),
  CONSTRAINT `FK_DBPUB_ENTITY_DESTINATION` FOREIGN KEY (`destinationId`) REFERENCES `cxml_destination` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_dbpub_entity`
--

LOCK TABLES `cxml_dbpub_entity` WRITE;
/*!40000 ALTER TABLE `cxml_dbpub_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_dbpub_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_dbpub_metadata`
--

DROP TABLE IF EXISTS `cxml_dbpub_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_dbpub_metadata` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `accountId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `entityId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DBPUB_METADATA_ENTITY` (`entityId`),
  CONSTRAINT `FK_DBPUB_METADATA_ENTITY` FOREIGN KEY (`entityId`) REFERENCES `cxml_dbpub_entity` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_dbpub_metadata`
--

LOCK TABLES `cxml_dbpub_metadata` WRITE;
/*!40000 ALTER TABLE `cxml_dbpub_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_dbpub_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_dbupdate`
--

DROP TABLE IF EXISTS `cxml_dbupdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_dbupdate` (
  `currentVersion` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_dbupdate`
--

LOCK TABLES `cxml_dbupdate` WRITE;
/*!40000 ALTER TABLE `cxml_dbupdate` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_dbupdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_destination`
--

DROP TABLE IF EXISTS `cxml_destination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_destination` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `directory` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transportId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isEnabled` tinyint(4) NOT NULL DEFAULT '0',
  `timeToPublish` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publishEvery` bigint(20) DEFAULT NULL,
  `publishEveryTimeUnit` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usesScheduledPublishing` tinyint(4) NOT NULL DEFAULT '0',
  `convertTextTo7Bit` tinyint(4) NOT NULL DEFAULT '0',
  `groups` text COLLATE utf8_unicode_ci,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_DEST_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_DEST_LOCK` (`lockId`),
  UNIQUE KEY `UQ_DEST_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_DEST_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_DEST_NEXTVERSION` (`nextVersionId`),
  KEY `FK_DEST_TARGET` (`targetId`),
  KEY `IDX_DEST_PATH` (`path`),
  KEY `FK_DEST_TRANSPORT` (`transportId`),
  KEY `FK_DEST_SITE` (`siteId`),
  CONSTRAINT `FK_DEST_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`),
  CONSTRAINT `FK_DEST_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_DEST_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_destination` (`id`),
  CONSTRAINT `FK_DEST_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_DEST_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_destination` (`id`),
  CONSTRAINT `FK_DEST_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_DEST_TARGET` FOREIGN KEY (`targetId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_DEST_TRANSPORT` FOREIGN KEY (`transportId`) REFERENCES `cxml_transport` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_destination`
--

LOCK TABLES `cxml_destination` WRITE;
/*!40000 ALTER TABLE `cxml_destination` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_destination` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_dynamicmetadatafield`
--

DROP TABLE IF EXISTS `cxml_dynamicmetadatafield`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_dynamicmetadatafield` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataValue` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `definitionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owningEntityId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DMF_OWNINGFCE` (`owningEntityId`),
  KEY `FK_DMF_DEFINITION` (`definitionId`),
  CONSTRAINT `FK_DMF_DEFINITION` FOREIGN KEY (`definitionId`) REFERENCES `cxml_dynamicmetadatafielddef` (`id`),
  CONSTRAINT `FK_DMF_OWNINGFCE` FOREIGN KEY (`owningEntityId`) REFERENCES `cxml_foldercontent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_dynamicmetadatafield`
--

LOCK TABLES `cxml_dynamicmetadatafield` WRITE;
/*!40000 ALTER TABLE `cxml_dynamicmetadatafield` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_dynamicmetadatafield` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_dynamicmetadatafielddef`
--

DROP TABLE IF EXISTS `cxml_dynamicmetadatafielddef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_dynamicmetadatafielddef` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataType` int(11) DEFAULT NULL,
  `required` tinyint(4) DEFAULT '0',
  `listingOrder` int(11) DEFAULT '0',
  `configuration` text COLLATE utf8_unicode_ci,
  `metadataSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `visibility` int(11) DEFAULT '1',
  `label` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DMFD_METADATASET` (`metadataSetId`),
  CONSTRAINT `FK_DMFD_METADATASET` FOREIGN KEY (`metadataSetId`) REFERENCES `cxml_metadataset` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_dynamicmetadatafielddef`
--

LOCK TABLES `cxml_dynamicmetadatafielddef` WRITE;
/*!40000 ALTER TABLE `cxml_dynamicmetadatafielddef` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_dynamicmetadatafielddef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_entitylock`
--

DROP TABLE IF EXISTS `cxml_entitylock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_entitylock` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `contentId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contentType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `who` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockDate` bigint(20) NOT NULL DEFAULT '0',
  `expirationDate` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ENTITYLOCK_USER` (`who`),
  KEY `IDX_LOCK_ASSET` (`contentId`,`contentType`),
  CONSTRAINT `FK_ENTITYLOCK_USER` FOREIGN KEY (`who`) REFERENCES `cxml_user` (`userName`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_entitylock`
--

LOCK TABLES `cxml_entitylock` WRITE;
/*!40000 ALTER TABLE `cxml_entitylock` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_entitylock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_entitymetadata`
--

DROP TABLE IF EXISTS `cxml_entitymetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_entitymetadata` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `createdBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastModifiedBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creationDate` bigint(20) DEFAULT '0',
  `lastModifiedDate` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_entitymetadata`
--

LOCK TABLES `cxml_entitymetadata` WRITE;
/*!40000 ALTER TABLE `cxml_entitymetadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_entitymetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_entityrelation`
--

DROP TABLE IF EXISTS `cxml_entityrelation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_entityrelation` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `blockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sddefinitionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stylesheetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relatedFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relatedFileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relatedPageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `velocityId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_EREL_TEMPLATE` (`templateId`),
  KEY `FK_EREL_RELFILE` (`relatedFileId`),
  KEY `FK_EREL_RELPAGE` (`relatedPageId`),
  KEY `FK_EREL_STYLESHEET` (`stylesheetId`),
  KEY `FK_EREL_BLOCK` (`blockId`),
  KEY `FK_EREL_PAGE` (`pageId`),
  KEY `FK_EREL_RELFOLDER` (`relatedFolderId`),
  KEY `FK_EREL_FILE` (`fileId`),
  KEY `FK_EREL_VELOCITY` (`velocityId`),
  CONSTRAINT `FK_EREL_BLOCK` FOREIGN KEY (`blockId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_FILE` FOREIGN KEY (`fileId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_PAGE` FOREIGN KEY (`pageId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_RELFILE` FOREIGN KEY (`relatedFileId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_RELFOLDER` FOREIGN KEY (`relatedFolderId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_RELPAGE` FOREIGN KEY (`relatedPageId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_STYLESHEET` FOREIGN KEY (`stylesheetId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_TEMPLATE` FOREIGN KEY (`templateId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_EREL_VELOCITY` FOREIGN KEY (`velocityId`) REFERENCES `cxml_foldercontent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_entityrelation`
--

LOCK TABLES `cxml_entityrelation` WRITE;
/*!40000 ALTER TABLE `cxml_entityrelation` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_entityrelation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_foldercontent`
--

DROP TABLE IF EXISTS `cxml_foldercontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_foldercontent` (
  `assetType` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cachePath` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relativeOrder` int(11) NOT NULL DEFAULT '0',
  `isRecycled` tinyint(4) NOT NULL DEFAULT '0',
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `displayName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keywords` text COLLATE utf8_unicode_ci,
  `summary` text COLLATE utf8_unicode_ci,
  `teaser` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `startDate` bigint(20) DEFAULT NULL,
  `endDate` bigint(20) DEFAULT NULL,
  `reviewDate` bigint(20) DEFAULT NULL,
  `expirationFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expirationNoticeSent` tinyint(4) NOT NULL DEFAULT '0',
  `firstExpirationWarningSent` tinyint(4) NOT NULL DEFAULT '0',
  `secondExpirationWarningSent` tinyint(4) NOT NULL DEFAULT '0',
  `workflowId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workflowComment` text COLLATE utf8_unicode_ci,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '0',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `originalCopyId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workingCopyId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isWorkingCopy` tinyint(4) NOT NULL DEFAULT '0',
  `lastDatePublished` bigint(20) DEFAULT NULL,
  `shouldBePublished` tinyint(4) NOT NULL DEFAULT '0',
  `lastPublishedBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shouldBeIndexed` tinyint(4) NOT NULL DEFAULT '0',
  `xmlId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockIndexedFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockDepthOfIndex` int(11) DEFAULT NULL,
  `blockIndexTypesBitmask` bigint(20) NOT NULL DEFAULT '2147483647',
  `blockIndexContentBitmask` bigint(20) NOT NULL DEFAULT '2147483647',
  `blockIndexOtherBitmask` bigint(20) NOT NULL DEFAULT '0',
  `blockSortOption` bigint(20) NOT NULL DEFAULT '1',
  `blockMaxRenderedEntities` int(11) NOT NULL DEFAULT '0',
  `blockFeedURL` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockIncludePageXML` tinyint(4) NOT NULL DEFAULT '0',
  `maintainAbsoluteLinks` tinyint(4) NOT NULL DEFAULT '0',
  `fileBlobId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileRewriteFileContents` tinyint(4) DEFAULT NULL,
  `folderPublishMergeFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `folderIsRoot` tinyint(1) NOT NULL DEFAULT '0',
  `pageStructuredDataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageStructuredDataDefinitionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageConfigurationSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageStructuredDataVersion` int(11) NOT NULL DEFAULT '1',
  `pageDefaultConfigurationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateTargetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateStylesheetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symlinkLink` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referenceBlockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referenceFileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referenceFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referencePageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referenceStylesheetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referenceSymlinkId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referenceTemplateId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recycleRecordId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `byteLength` bigint(20) NOT NULL DEFAULT '0',
  `draftOriginalId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `draftUserId` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contentTypeId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockIndexedContentTypeId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockSortOrder` bigint(20) NOT NULL DEFAULT '1',
  `indexBlockType` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `folderWorkflowInheritDefs` tinyint(4) NOT NULL DEFAULT '1',
  `folderWorkflowRequire` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_FCE_LOCK` (`lockId`),
  UNIQUE KEY `UQ_FCE_PAGESTRUCTUREDDATA` (`pageStructuredDataId`),
  UNIQUE KEY `UQ_FCE_XML` (`xmlId`),
  UNIQUE KEY `UQ_FCE_WORKFLOW` (`workflowId`),
  UNIQUE KEY `UQ_FCE_FILEBLOB` (`fileBlobId`),
  UNIQUE KEY `UQ_FCE_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_FCE_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_FCE_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_FCE_METADATA` (`metadataId`),
  KEY `FK_FCE_REFERENCE_FOLDER` (`referenceFolderId`),
  KEY `FK_FCE_DRAFTORIGINAL` (`draftOriginalId`),
  KEY `FK_FCE_METADATASET` (`metadataSetId`),
  KEY `FK_FCE_DRAFTUSER` (`draftUserId`),
  KEY `FK_FCE_REFERENCE_SYMLINK` (`referenceSymlinkId`),
  KEY `FK_FCE_REFERENCE_FILE` (`referenceFileId`),
  KEY `FK_FCE_REFERENCE_TEMPLATE` (`referenceTemplateId`),
  KEY `FK_FCE_EXPIRYFOLDER` (`expirationFolderId`),
  KEY `FK_FCE_PAGEDATADEF` (`pageStructuredDataDefinitionId`),
  KEY `FK_FCE_REFERENCE_BLOCK` (`referenceBlockId`),
  KEY `FK_FCE_PAGE_DEFAULTPAGECONFIG` (`pageDefaultConfigurationId`),
  KEY `FK_FCE_CONTENTTYPE` (`contentTypeId`),
  KEY `FK_FCE_PAGE_PAGECONFIGSET` (`pageConfigurationSetId`),
  KEY `FK_FCE_WORKINGCOPY` (`workingCopyId`),
  KEY `FK_FCE_RECYCLERECORD` (`recycleRecordId`),
  KEY `FK_FCE_ORIGINALCOPY` (`originalCopyId`),
  KEY `FK_FCE_PARENTFOLDER` (`parentFolderId`),
  KEY `FK_FCE_REFERENCE_PAGE` (`referencePageId`),
  KEY `FK_FCE_REFERENCE_STYLESHEET` (`referenceStylesheetId`),
  KEY `FK_FCE_BLOCK_INDEXEDFOLDER` (`blockIndexedFolderId`),
  KEY `FK_FCE_FOLPUBMERGEFOLDER` (`folderPublishMergeFolderId`),
  KEY `FK_FCE_TEMPLATE_TARGET` (`templateTargetId`),
  KEY `FK_FCE_TEMPLATE_STYLESHEET` (`templateStylesheetId`),
  KEY `IDX_FCE_PATH` (`cachePath`),
  KEY `FK_FCE_BLOCK_INDEXEDCTTYPE` (`blockIndexedContentTypeId`),
  KEY `FK_FCE_SITE` (`siteId`),
  KEY `IDX_FCE_FOLDERISROOT` (`folderIsRoot`),
  CONSTRAINT `FK_FCE_BLOCK_INDEXEDCTTYPE` FOREIGN KEY (`blockIndexedContentTypeId`) REFERENCES `cxml_contenttype` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_BLOCK_INDEXEDFOLDER` FOREIGN KEY (`blockIndexedFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_CONTENTTYPE` FOREIGN KEY (`contentTypeId`) REFERENCES `cxml_contenttype` (`id`),
  CONSTRAINT `FK_FCE_DRAFTORIGINAL` FOREIGN KEY (`draftOriginalId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_FCE_DRAFTUSER` FOREIGN KEY (`draftUserId`) REFERENCES `cxml_user` (`userName`),
  CONSTRAINT `FK_FCE_EXPIRYFOLDER` FOREIGN KEY (`expirationFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_FILEBLOB` FOREIGN KEY (`fileBlobId`) REFERENCES `cxml_blob` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_FOLPUBMERGEFOLDER` FOREIGN KEY (`folderPublishMergeFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`),
  CONSTRAINT `FK_FCE_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_FCE_METADATASET` FOREIGN KEY (`metadataSetId`) REFERENCES `cxml_metadataset` (`id`),
  CONSTRAINT `FK_FCE_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_ORIGINALCOPY` FOREIGN KEY (`originalCopyId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_PAGEDATADEF` FOREIGN KEY (`pageStructuredDataDefinitionId`) REFERENCES `cxml_structureddatadefinition` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_PAGESTRUCTUREDDATA` FOREIGN KEY (`pageStructuredDataId`) REFERENCES `cxml_structureddata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_PAGE_DEFAULTPAGECONFIG` FOREIGN KEY (`pageDefaultConfigurationId`) REFERENCES `cxml_pageconfiguration` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_PAGE_PAGECONFIGSET` FOREIGN KEY (`pageConfigurationSetId`) REFERENCES `cxml_pageconfigurationset` (`id`),
  CONSTRAINT `FK_FCE_PARENTFOLDER` FOREIGN KEY (`parentFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_RECYCLERECORD` FOREIGN KEY (`recycleRecordId`) REFERENCES `cxml_recyclerecord` (`id`),
  CONSTRAINT `FK_FCE_REFERENCE_BLOCK` FOREIGN KEY (`referenceBlockId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_REFERENCE_FILE` FOREIGN KEY (`referenceFileId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_REFERENCE_FOLDER` FOREIGN KEY (`referenceFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_REFERENCE_PAGE` FOREIGN KEY (`referencePageId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_REFERENCE_STYLESHEET` FOREIGN KEY (`referenceStylesheetId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_REFERENCE_SYMLINK` FOREIGN KEY (`referenceSymlinkId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_REFERENCE_TEMPLATE` FOREIGN KEY (`referenceTemplateId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_FCE_TEMPLATE_STYLESHEET` FOREIGN KEY (`templateStylesheetId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_TEMPLATE_TARGET` FOREIGN KEY (`templateTargetId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_FCE_WORKFLOW` FOREIGN KEY (`workflowId`) REFERENCES `cxml_workflow` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_WORKINGCOPY` FOREIGN KEY (`workingCopyId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_FCE_XML` FOREIGN KEY (`xmlId`) REFERENCES `cxml_xml` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_foldercontent`
--

LOCK TABLES `cxml_foldercontent` WRITE;
/*!40000 ALTER TABLE `cxml_foldercontent` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_foldercontent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_folders_wfdefs`
--

DROP TABLE IF EXISTS `cxml_folders_wfdefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_folders_wfdefs` (
  `folderId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `definitionId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`folderId`,`definitionId`),
  KEY `FK_FOLWFDEF_DEFINITION` (`definitionId`),
  CONSTRAINT `FK_FOLWFDEF_DEFINITION` FOREIGN KEY (`definitionId`) REFERENCES `cxml_workflowdefinition` (`id`),
  CONSTRAINT `FK_FOLWFDEF_FOLDER` FOREIGN KEY (`folderId`) REFERENCES `cxml_foldercontent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_folders_wfdefs`
--

LOCK TABLES `cxml_folders_wfdefs` WRITE;
/*!40000 ALTER TABLE `cxml_folders_wfdefs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_folders_wfdefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_group`
--

DROP TABLE IF EXISTS `cxml_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_group` (
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `CSSCLASSES` text COLLATE utf8_unicode_ci,
  `allowFontFormatting` tinyint(4) NOT NULL DEFAULT '1',
  `allowTextFormatting` tinyint(4) NOT NULL DEFAULT '1',
  `allowFontAssignment` tinyint(4) NOT NULL DEFAULT '1',
  `allowViewSource` tinyint(4) NOT NULL DEFAULT '1',
  `allowInsertTable` tinyint(4) NOT NULL DEFAULT '1',
  `allowInsertImage` tinyint(4) NOT NULL DEFAULT '1',
  `startingPageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `baseFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `baseAssetFactoryContainerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `FK_GROUP_AFC` (`baseAssetFactoryContainerId`),
  KEY `FK_GROUP_STARTPAGE` (`startingPageId`),
  KEY `FK_GROUP_BASEFOLDER` (`baseFolderId`),
  CONSTRAINT `FK_GROUP_AFC` FOREIGN KEY (`baseAssetFactoryContainerId`) REFERENCES `cxml_assetfactorycontainer` (`id`),
  CONSTRAINT `FK_GROUP_BASEFOLDER` FOREIGN KEY (`baseFolderId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_GROUP_STARTPAGE` FOREIGN KEY (`startingPageId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_group`
--

LOCK TABLES `cxml_group` WRITE;
/*!40000 ALTER TABLE `cxml_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_group_membership`
--

DROP TABLE IF EXISTS `cxml_group_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_group_membership` (
  `userName` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `groupName` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  KEY `IDX_GROUPMEM_GROUP` (`groupName`),
  KEY `IDX_GROUPMEM_USER` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_group_membership`
--

LOCK TABLES `cxml_group_membership` WRITE;
/*!40000 ALTER TABLE `cxml_group_membership` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_group_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_last_modified`
--

DROP TABLE IF EXISTS `cxml_last_modified`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_last_modified` (
  `localLastPublished` bigint(20) NOT NULL DEFAULT '0',
  `remoteLastModified` bigint(20) NOT NULL DEFAULT '0',
  `entityId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `destinationId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`destinationId`,`entityId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_last_modified`
--

LOCK TABLES `cxml_last_modified` WRITE;
/*!40000 ALTER TABLE `cxml_last_modified` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_last_modified` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_lock`
--

DROP TABLE IF EXISTS `cxml_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_lock` (
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_lock`
--

LOCK TABLES `cxml_lock` WRITE;
/*!40000 ALTER TABLE `cxml_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_login`
--

DROP TABLE IF EXISTS `cxml_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_login` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `loginTime` bigint(20) unsigned NOT NULL,
  `lastSeen` bigint(20) unsigned NOT NULL,
  `remoteHost` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `valid` tinyint(4) unsigned NOT NULL,
  `lastViewedScreen` int(11) unsigned DEFAULT NULL,
  `assetId` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assetType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bootMessageKey` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bootMessageArg` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sessionId` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sessionCheckIn` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_LOGIN_USERNAME` (`username`),
  KEY `IDX_LOGIN_SESSION` (`sessionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_login`
--

LOCK TABLES `cxml_login` WRITE;
/*!40000 ALTER TABLE `cxml_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_mail`
--

DROP TABLE IF EXISTS `cxml_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_mail` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `messageBody` longtext COLLATE utf8_unicode_ci,
  `sender` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receiver` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendDate` bigint(20) NOT NULL DEFAULT '0',
  `receiveDate` bigint(20) NOT NULL DEFAULT '0',
  `hasBeenRead` tinyint(4) NOT NULL DEFAULT '0',
  `subject` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isBroadcast` tinyint(4) DEFAULT '0',
  `urgency` tinyint(4) DEFAULT '0',
  `parentId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_MAIL_RECIPIENT` (`receiver`),
  KEY `IDX_MESSAGE_PARENT` (`parentId`),
  KEY `IDX_MAIL_SEND_DATE` (`sendDate`),
  KEY `IDX_MAIL_RECEIVE_DATE` (`receiveDate`),
  CONSTRAINT `FK_MESSAGE_PARENT` FOREIGN KEY (`parentId`) REFERENCES `cxml_mail` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_mail`
--

LOCK TABLES `cxml_mail` WRITE;
/*!40000 ALTER TABLE `cxml_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_metadataset`
--

DROP TABLE IF EXISTS `cxml_metadataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_metadataset` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vis_displayname` int(11) DEFAULT NULL,
  `vis_title` int(11) DEFAULT NULL,
  `vis_summary` int(11) DEFAULT NULL,
  `vis_teaser` int(11) DEFAULT NULL,
  `vis_keywords` int(11) DEFAULT NULL,
  `vis_description` int(11) DEFAULT NULL,
  `vis_author` int(11) DEFAULT NULL,
  `vis_expirationfolder` int(11) DEFAULT NULL,
  `vis_startdate` int(11) DEFAULT NULL,
  `vis_enddate` int(11) DEFAULT NULL,
  `vis_reviewdate` tinyint(4) DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `req_author` tinyint(4) NOT NULL DEFAULT '0',
  `req_description` tinyint(4) NOT NULL DEFAULT '0',
  `req_displayname` tinyint(4) NOT NULL DEFAULT '0',
  `req_enddate` tinyint(4) NOT NULL DEFAULT '0',
  `req_reviewdate` tinyint(4) NOT NULL DEFAULT '0',
  `req_expirationfolder` tinyint(4) NOT NULL DEFAULT '0',
  `req_keywords` tinyint(4) NOT NULL DEFAULT '0',
  `req_startdate` tinyint(4) NOT NULL DEFAULT '0',
  `req_summary` tinyint(4) NOT NULL DEFAULT '0',
  `req_teaser` tinyint(4) NOT NULL DEFAULT '0',
  `req_title` tinyint(4) NOT NULL DEFAULT '0',
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_MDSET_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_MDSET_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_MDSET_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_MDSET_LOCK` (`lockId`),
  UNIQUE KEY `UQ_MDSET_PREVVERSION` (`prevVersionId`),
  KEY `FK_MDSET_CONTAINER` (`containerId`),
  KEY `IDX_MDSET_PATH` (`path`),
  KEY `FK_MDSET_SITE` (`siteId`),
  CONSTRAINT `FK_MDSET_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_metadatasetcontainer` (`id`),
  CONSTRAINT `FK_MDSET_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_MDSET_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_MDSET_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_metadataset` (`id`),
  CONSTRAINT `FK_MDSET_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_MDSET_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_metadataset` (`id`),
  CONSTRAINT `FK_MDSET_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_metadataset`
--

LOCK TABLES `cxml_metadataset` WRITE;
/*!40000 ALTER TABLE `cxml_metadataset` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_metadataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_metadatasetcontainer`
--

DROP TABLE IF EXISTS `cxml_metadatasetcontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_metadatasetcontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_MSC_LOCK` (`lockId`),
  UNIQUE KEY `UQ_MSC_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_MSC_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_MSC_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_MSC_NEXTVERSION` (`nextVersionId`),
  KEY `FK_MSC_CONTAINER` (`containerId`),
  KEY `IDX_MSC_PATH` (`path`),
  KEY `FK_MSC_SITE` (`siteId`),
  CONSTRAINT `FK_MSC_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_metadatasetcontainer` (`id`),
  CONSTRAINT `FK_MSC_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_MSC_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_MSC_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_metadatasetcontainer` (`id`),
  CONSTRAINT `FK_MSC_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_MSC_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_metadatasetcontainer` (`id`),
  CONSTRAINT `FK_MSC_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_metadatasetcontainer`
--

LOCK TABLES `cxml_metadatasetcontainer` WRITE;
/*!40000 ALTER TABLE `cxml_metadatasetcontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_metadatasetcontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_pageconfigsetcont`
--

DROP TABLE IF EXISTS `cxml_pageconfigsetcont`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_pageconfigsetcont` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_PCSC_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_PCSC_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_PCSC_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_PCSC_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_PCSC_LOCK` (`lockId`),
  KEY `FK_PCSC_CONTAINER` (`containerId`),
  KEY `IDX_PCSC_PATH` (`path`),
  KEY `FK_PCSC_SITE` (`siteId`),
  CONSTRAINT `FK_PCSC_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_pageconfigsetcont` (`id`),
  CONSTRAINT `FK_PCSC_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PCSC_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_PCSC_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_pageconfigsetcont` (`id`),
  CONSTRAINT `FK_PCSC_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PCSC_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_pageconfigsetcont` (`id`),
  CONSTRAINT `FK_PCSC_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_pageconfigsetcont`
--

LOCK TABLES `cxml_pageconfigsetcont` WRITE;
/*!40000 ALTER TABLE `cxml_pageconfigsetcont` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_pageconfigsetcont` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_pageconfiguration`
--

DROP TABLE IF EXISTS `cxml_pageconfiguration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_pageconfiguration` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageConfigurationSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentConfigurationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stylesheetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extension` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serializationType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shouldIncludeXMLDeclaration` tinyint(4) NOT NULL DEFAULT '0',
  `publishable` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_PGCFG_STYLESHEET` (`stylesheetId`),
  KEY `FK_PGCFG_PARENTCONFIG` (`parentConfigurationId`),
  KEY `FK_PGCFG_TEMPLATE` (`templateId`),
  KEY `FK_PGCFG_PAGE` (`pageId`),
  KEY `FK_PGCFG_CONFIGSET` (`pageConfigurationSetId`),
  CONSTRAINT `FK_PGCFG_CONFIGSET` FOREIGN KEY (`pageConfigurationSetId`) REFERENCES `cxml_pageconfigurationset` (`id`),
  CONSTRAINT `FK_PGCFG_PAGE` FOREIGN KEY (`pageId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PGCFG_PARENTCONFIG` FOREIGN KEY (`parentConfigurationId`) REFERENCES `cxml_pageconfiguration` (`id`),
  CONSTRAINT `FK_PGCFG_STYLESHEET` FOREIGN KEY (`stylesheetId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PGCFG_TEMPLATE` FOREIGN KEY (`templateId`) REFERENCES `cxml_foldercontent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_pageconfiguration`
--

LOCK TABLES `cxml_pageconfiguration` WRITE;
/*!40000 ALTER TABLE `cxml_pageconfiguration` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_pageconfiguration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_pageconfigurationset`
--

DROP TABLE IF EXISTS `cxml_pageconfigurationset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_pageconfigurationset` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `defaultConfigurationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_PCSET_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_PCSET_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_PCSET_DEFAULTCONFIG` (`defaultConfigurationId`),
  UNIQUE KEY `UQ_PCSET_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_PCSET_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_PCSET_LOCK` (`lockId`),
  KEY `FK_PCSET_CONTAINER` (`containerId`),
  KEY `IDX_PCSET_PATH` (`path`),
  KEY `FK_PCSET_SITE` (`siteId`),
  CONSTRAINT `FK_PCSET_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_pageconfigsetcont` (`id`),
  CONSTRAINT `FK_PCSET_DEFAULTCONFIG` FOREIGN KEY (`defaultConfigurationId`) REFERENCES `cxml_pageconfiguration` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PCSET_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`),
  CONSTRAINT `FK_PCSET_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_PCSET_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_pageconfigurationset` (`id`),
  CONSTRAINT `FK_PCSET_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`),
  CONSTRAINT `FK_PCSET_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_pageconfigurationset` (`id`),
  CONSTRAINT `FK_PCSET_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_pageconfigurationset`
--

LOCK TABLES `cxml_pageconfigurationset` WRITE;
/*!40000 ALTER TABLE `cxml_pageconfigurationset` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_pageconfigurationset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_pageregion`
--

DROP TABLE IF EXISTS `cxml_pageregion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_pageregion` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageConfigurationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stylesheetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stylesheetOverrides` tinyint(1) NOT NULL DEFAULT '0',
  `blockOverrides` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_PAGREG_TEMPLATE` (`templateId`),
  KEY `FK_PAGREG_STYLESHEET` (`stylesheetId`),
  KEY `FK_PAGREG_BLOCK` (`blockId`),
  KEY `FK_PAGREG_CONFIG` (`pageConfigurationId`),
  CONSTRAINT `FK_PAGREG_BLOCK` FOREIGN KEY (`blockId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PAGREG_CONFIG` FOREIGN KEY (`pageConfigurationId`) REFERENCES `cxml_pageconfiguration` (`id`),
  CONSTRAINT `FK_PAGREG_STYLESHEET` FOREIGN KEY (`stylesheetId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PAGREG_TEMPLATE` FOREIGN KEY (`templateId`) REFERENCES `cxml_foldercontent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_pageregion`
--

LOCK TABLES `cxml_pageregion` WRITE;
/*!40000 ALTER TABLE `cxml_pageregion` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_pageregion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_permissions`
--

DROP TABLE IF EXISTS `cxml_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_permissions` (
  `userPermissionsLevel` int(11) DEFAULT NULL,
  `groupPermissionsLevel` int(11) DEFAULT NULL,
  `groupName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `allPermissionsLevel` bigint(20) NOT NULL DEFAULT '0',
  `permissionsVersion` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_permissions`
--

LOCK TABLES `cxml_permissions` WRITE;
/*!40000 ALTER TABLE `cxml_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_preferences`
--

DROP TABLE IF EXISTS `cxml_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_preferences` (
  `fieldName` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `fieldValue` text COLLATE utf8_unicode_ci,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`username`,`fieldName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_preferences`
--

LOCK TABLES `cxml_preferences` WRITE;
/*!40000 ALTER TABLE `cxml_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_publishrequest`
--

DROP TABLE IF EXISTS `cxml_publishrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_publishrequest` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `fileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `folderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destinationId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `generateReport` tinyint(1) NOT NULL DEFAULT '0',
  `unpublish` tinyint(1) NOT NULL DEFAULT '0',
  `requestDate` bigint(20) NOT NULL DEFAULT '0',
  `startDate` bigint(20) NOT NULL DEFAULT '0',
  `endDate` bigint(20) NOT NULL DEFAULT '0',
  `publishSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `percentDone` double NOT NULL DEFAULT '0',
  `cancelled` tinyint(1) NOT NULL DEFAULT '0',
  `workingCopyPublish` tinyint(1) NOT NULL DEFAULT '0',
  `nextId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publishAllDestinations` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_PUBREQUEST_PREV` (`prevId`),
  KEY `FK_PUBREQ_TARGET` (`targetId`),
  KEY `FK_PUBREQ_FOLDER` (`folderId`),
  KEY `FK_PUBREQ_PAGE` (`pageId`),
  KEY `FK_PUBREQ_DESTINATION` (`destinationId`),
  KEY `FK_PUBREQ_USER` (`username`),
  KEY `FK_PUBREQ_FILE` (`fileId`),
  KEY `FK_PUBREQ_PUBSET` (`publishSetId`),
  KEY `IDX_PUBREQ_REQUESTDATE` (`requestDate`),
  KEY `FK_PUBREQ_SITE` (`siteId`),
  CONSTRAINT `FK_PUBREQ_DESTINATION` FOREIGN KEY (`destinationId`) REFERENCES `cxml_destination` (`id`),
  CONSTRAINT `FK_PUBREQ_FILE` FOREIGN KEY (`fileId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PUBREQ_FOLDER` FOREIGN KEY (`folderId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PUBREQ_PAGE` FOREIGN KEY (`pageId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PUBREQ_PUBSET` FOREIGN KEY (`publishSetId`) REFERENCES `cxml_publishset` (`id`),
  CONSTRAINT `FK_PUBREQ_REQ_PREV` FOREIGN KEY (`prevId`) REFERENCES `cxml_publishrequest` (`id`),
  CONSTRAINT `FK_PUBREQ_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_PUBREQ_TARGET` FOREIGN KEY (`targetId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_PUBREQ_USER` FOREIGN KEY (`username`) REFERENCES `cxml_user` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_publishrequest`
--

LOCK TABLES `cxml_publishrequest` WRITE;
/*!40000 ALTER TABLE `cxml_publishrequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_publishrequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_publishrequest_config`
--

DROP TABLE IF EXISTS `cxml_publishrequest_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_publishrequest_config` (
  `publishRequestId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `pageConfigurationId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`publishRequestId`,`pageConfigurationId`),
  KEY `FK_PUBREQCONFIG_CONFIG` (`pageConfigurationId`),
  CONSTRAINT `FK_PUBREQCONFIG_CONFIG` FOREIGN KEY (`pageConfigurationId`) REFERENCES `cxml_pageconfiguration` (`id`),
  CONSTRAINT `FK_PUBREQCONFIG_PUBREQ` FOREIGN KEY (`publishRequestId`) REFERENCES `cxml_publishrequest` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_publishrequest_config`
--

LOCK TABLES `cxml_publishrequest_config` WRITE;
/*!40000 ALTER TABLE `cxml_publishrequest_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_publishrequest_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_publishrequest_dest`
--

DROP TABLE IF EXISTS `cxml_publishrequest_dest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_publishrequest_dest` (
  `publishRequestId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `destinationId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`publishRequestId`,`destinationId`),
  KEY `FK_PUBREQDEST_DEST` (`destinationId`),
  CONSTRAINT `FK_PUBREQDEST_DEST` FOREIGN KEY (`destinationId`) REFERENCES `cxml_destination` (`id`),
  CONSTRAINT `FK_PUBREQDEST_PUBREQ` FOREIGN KEY (`publishRequestId`) REFERENCES `cxml_publishrequest` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_publishrequest_dest`
--

LOCK TABLES `cxml_publishrequest_dest` WRITE;
/*!40000 ALTER TABLE `cxml_publishrequest_dest` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_publishrequest_dest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_publishset`
--

DROP TABLE IF EXISTS `cxml_publishset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_publishset` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timeToPublish` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publishEvery` bigint(20) DEFAULT NULL,
  `publishEveryTimeUnit` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usesScheduledPublishing` tinyint(4) NOT NULL DEFAULT '0',
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_PUBSET_LOCK` (`lockId`),
  UNIQUE KEY `UQ_PUBSET_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_PUBSET_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_PUBSET_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_PUBSET_METADATA` (`metadataId`),
  KEY `FK_PUBSET_CONTAINER` (`containerId`),
  KEY `IDX_PUBSET_PATH` (`path`),
  KEY `FK_PUBSET_SITE` (`siteId`),
  CONSTRAINT `FK_PUBSET_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_publishsetcontainer` (`id`),
  CONSTRAINT `FK_PUBSET_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PUBSET_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PUBSET_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_publishset` (`id`),
  CONSTRAINT `FK_PUBSET_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PUBSET_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_publishset` (`id`),
  CONSTRAINT `FK_PUBSET_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_publishset`
--

LOCK TABLES `cxml_publishset` WRITE;
/*!40000 ALTER TABLE `cxml_publishset` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_publishset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_publishsetcontainer`
--

DROP TABLE IF EXISTS `cxml_publishsetcontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_publishsetcontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_PSC_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_PSC_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_PSC_LOCK` (`lockId`),
  UNIQUE KEY `UQ_PSC_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_PSC_METADATA` (`metadataId`),
  KEY `FK_PSC_CONTAINER` (`containerId`),
  KEY `IDX_PSC_PATH` (`path`),
  KEY `FK_PSC_SITE` (`siteId`),
  CONSTRAINT `FK_PSC_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_publishsetcontainer` (`id`),
  CONSTRAINT `FK_PSC_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PSC_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PSC_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_publishsetcontainer` (`id`),
  CONSTRAINT `FK_PSC_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_PSC_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_publishsetcontainer` (`id`),
  CONSTRAINT `FK_PSC_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_publishsetcontainer`
--

LOCK TABLES `cxml_publishsetcontainer` WRITE;
/*!40000 ALTER TABLE `cxml_publishsetcontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_publishsetcontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_publishsetrecord`
--

DROP TABLE IF EXISTS `cxml_publishsetrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_publishsetrecord` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `pageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `folderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publishSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PUBSETREC_PAGE` (`pageId`),
  KEY `FK_PUBSETREC_PUBSET` (`publishSetId`),
  KEY `FK_PUBSETREC_FILE` (`fileId`),
  KEY `FK_PUBSETREC_FOLDER` (`folderId`),
  CONSTRAINT `FK_PUBSETREC_FILE` FOREIGN KEY (`fileId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PUBSETREC_FOLDER` FOREIGN KEY (`folderId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PUBSETREC_PAGE` FOREIGN KEY (`pageId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_PUBSETREC_PUBSET` FOREIGN KEY (`publishSetId`) REFERENCES `cxml_publishset` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_publishsetrecord`
--

LOCK TABLES `cxml_publishsetrecord` WRITE;
/*!40000 ALTER TABLE `cxml_publishsetrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_publishsetrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_recyclerecord`
--

DROP TABLE IF EXISTS `cxml_recyclerecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_recyclerecord` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `recycledBy` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `parentFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recycledOn` bigint(20) NOT NULL DEFAULT '0',
  `unpublishRequestId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recycleState` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_RECYCLERECORD_FOLDER` (`parentFolderId`),
  KEY `FK_RECYCLERECORD_PUBREQ` (`unpublishRequestId`),
  CONSTRAINT `FK_RECYCLERECORD_FOLDER` FOREIGN KEY (`parentFolderId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_RECYCLERECORD_PUBREQ` FOREIGN KEY (`unpublishRequestId`) REFERENCES `cxml_publishrequest` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_recyclerecord`
--

LOCK TABLES `cxml_recyclerecord` WRITE;
/*!40000 ALTER TABLE `cxml_recyclerecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_recyclerecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_role_group_link`
--

DROP TABLE IF EXISTS `cxml_role_group_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_role_group_link` (
  `roleId` int(11) NOT NULL,
  `groupName` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`roleId`,`groupName`),
  CONSTRAINT `FK_ROLEGROUP_ROLE` FOREIGN KEY (`roleId`) REFERENCES `cxml_roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_role_group_link`
--

LOCK TABLES `cxml_role_group_link` WRITE;
/*!40000 ALTER TABLE `cxml_role_group_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_role_group_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_role_group_site_link`
--

DROP TABLE IF EXISTS `cxml_role_group_site_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_role_group_site_link` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `roleId` int(11) NOT NULL,
  `groupName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ROLEGROUPSITE_SITE` (`siteId`),
  KEY `FK_ROLEGROUPSITE_GROUP` (`groupName`),
  KEY `FK_ROLEGROUPSITE_ROLE` (`roleId`),
  CONSTRAINT `FK_ROLEGROUPSITE_GROUP` FOREIGN KEY (`groupName`) REFERENCES `cxml_group` (`name`),
  CONSTRAINT `FK_ROLEGROUPSITE_ROLE` FOREIGN KEY (`roleId`) REFERENCES `cxml_roles` (`id`),
  CONSTRAINT `FK_ROLEGROUPSITE_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_role_group_site_link`
--

LOCK TABLES `cxml_role_group_site_link` WRITE;
/*!40000 ALTER TABLE `cxml_role_group_site_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_role_group_site_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_role_user_link`
--

DROP TABLE IF EXISTS `cxml_role_user_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_role_user_link` (
  `roleId` int(11) NOT NULL,
  `userName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`roleId`,`userName`),
  KEY `FK_ROLEUSER_USER` (`userName`),
  CONSTRAINT `FK_ROLEUSER_ROLE` FOREIGN KEY (`roleId`) REFERENCES `cxml_roles` (`id`),
  CONSTRAINT `FK_ROLEUSER_USER` FOREIGN KEY (`userName`) REFERENCES `cxml_user` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_role_user_link`
--

LOCK TABLES `cxml_role_user_link` WRITE;
/*!40000 ALTER TABLE `cxml_role_user_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_role_user_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_role_user_site_link`
--

DROP TABLE IF EXISTS `cxml_role_user_site_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_role_user_site_link` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `roleId` int(11) NOT NULL,
  `userName` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ROLEUSERSITE_SITE` (`siteId`),
  KEY `FK_ROLEUSERSITE_USER` (`userName`),
  KEY `FK_ROLEUSERSITE_ROLE` (`roleId`),
  CONSTRAINT `FK_ROLEUSERSITE_ROLE` FOREIGN KEY (`roleId`) REFERENCES `cxml_roles` (`id`),
  CONSTRAINT `FK_ROLEUSERSITE_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_ROLEUSERSITE_USER` FOREIGN KEY (`userName`) REFERENCES `cxml_user` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_role_user_site_link`
--

LOCK TABLES `cxml_role_user_site_link` WRITE;
/*!40000 ALTER TABLE `cxml_role_user_site_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_role_user_site_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_roles`
--

DROP TABLE IF EXISTS `cxml_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleName` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `globalAbilities` int(11) NOT NULL DEFAULT '0',
  `adminAreaAbilities` int(11) NOT NULL DEFAULT '0',
  `securityAreaAbilities` int(11) NOT NULL DEFAULT '0',
  `homeAreaAbilities` int(11) NOT NULL DEFAULT '0',
  `toolsAbilities` int(11) NOT NULL DEFAULT '0',
  `global` tinyint(4) NOT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sitesAbilities` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_ROLES_PERMISSIONS` (`permissionsId`),
  CONSTRAINT `FK_ROLES_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_roles`
--

LOCK TABLES `cxml_roles` WRITE;
/*!40000 ALTER TABLE `cxml_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_site`
--

DROP TABLE IF EXISTS `cxml_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_site` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL,
  `cssClasses` text COLLATE utf8_unicode_ci,
  `cssFileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `defaultMetadataSetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publishEvery` bigint(20) DEFAULT NULL,
  `publishEveryTimeUnit` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timeToPublish` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usesScheduledPublishing` tinyint(4) NOT NULL DEFAULT '0',
  `baseAssetFactoryContainerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startingPageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_SITE_NAME` (`name`),
  UNIQUE KEY `UQ_SITE_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_SITE_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_SITE_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_SITE_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_SITE_LOCK` (`lockId`),
  KEY `FK_SITE_CSSFILE` (`cssFileId`),
  KEY `FK_SITE_DEFAULTMETADATASET` (`defaultMetadataSetId`),
  KEY `IDX_SITE_PATH` (`path`),
  KEY `FK_SITE_STARTPAGE` (`startingPageId`),
  KEY `FK_SITE_AFC` (`baseAssetFactoryContainerId`),
  CONSTRAINT `FK_SITE_AFC` FOREIGN KEY (`baseAssetFactoryContainerId`) REFERENCES `cxml_assetfactorycontainer` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SITE_CSSFILE` FOREIGN KEY (`cssFileId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SITE_DEFAULTMETADATASET` FOREIGN KEY (`defaultMetadataSetId`) REFERENCES `cxml_metadataset` (`id`),
  CONSTRAINT `FK_SITE_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SITE_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_SITE_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_SITE_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SITE_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_SITE_STARTPAGE` FOREIGN KEY (`startingPageId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_site`
--

LOCK TABLES `cxml_site` WRITE;
/*!40000 ALTER TABLE `cxml_site` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_site_roles`
--

DROP TABLE IF EXISTS `cxml_site_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_site_roles` (
  `siteId` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`siteId`,`roleId`),
  KEY `FK_SITEROLES_ROLE` (`roleId`),
  CONSTRAINT `FK_SITEROLES_ROLE` FOREIGN KEY (`roleId`) REFERENCES `cxml_roles` (`id`),
  CONSTRAINT `FK_SITEROLES_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_site_roles`
--

LOCK TABLES `cxml_site_roles` WRITE;
/*!40000 ALTER TABLE `cxml_site_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_site_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_structureddata`
--

DROP TABLE IF EXISTS `cxml_structureddata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_structureddata` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `structuredDataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `textData` longtext COLLATE utf8_unicode_ci,
  `structuredDataType` tinyint(4) NOT NULL DEFAULT '0',
  `groupStructuredDataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symlinkId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assetType` int(11) DEFAULT '1',
  `pageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `textVersion` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `ownerPageId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_SDATA_PAGE` (`pageId`),
  KEY `FK_SDATA_NEXT` (`structuredDataId`),
  KEY `FK_SDATA_GROUP` (`groupStructuredDataId`),
  KEY `FK_SDATA_OWNERPAGE` (`ownerPageId`),
  KEY `FK_SDATA_BLOCK` (`blockId`),
  KEY `FK_SDATA_FILE` (`fileId`),
  KEY `FK_SDATA_SYMLINK` (`symlinkId`),
  CONSTRAINT `FK_SDATA_BLOCK` FOREIGN KEY (`blockId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDATA_FILE` FOREIGN KEY (`fileId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDATA_GROUP` FOREIGN KEY (`groupStructuredDataId`) REFERENCES `cxml_structureddata` (`id`),
  CONSTRAINT `FK_SDATA_NEXT` FOREIGN KEY (`structuredDataId`) REFERENCES `cxml_structureddata` (`id`),
  CONSTRAINT `FK_SDATA_OWNERPAGE` FOREIGN KEY (`ownerPageId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_SDATA_PAGE` FOREIGN KEY (`pageId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDATA_SYMLINK` FOREIGN KEY (`symlinkId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_structureddata`
--

LOCK TABLES `cxml_structureddata` WRITE;
/*!40000 ALTER TABLE `cxml_structureddata` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_structureddata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_structureddatadefcont`
--

DROP TABLE IF EXISTS `cxml_structureddatadefcont`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_structureddatadefcont` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_SDDC_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_SDDC_LOCK` (`lockId`),
  UNIQUE KEY `UQ_SDDC_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_SDDC_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_SDDC_PERMISSIONS` (`permissionsId`),
  KEY `FK_SDDC_CONTAINER` (`containerId`),
  KEY `IDX_SDDC_PATH` (`path`),
  KEY `FK_SDDC_SITE` (`siteId`),
  CONSTRAINT `FK_SDDC_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_structureddatadefcont` (`id`),
  CONSTRAINT `FK_SDDC_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDDC_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDDC_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_structureddatadefcont` (`id`),
  CONSTRAINT `FK_SDDC_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDDC_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_structureddatadefcont` (`id`),
  CONSTRAINT `FK_SDDC_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_structureddatadefcont`
--

LOCK TABLES `cxml_structureddatadefcont` WRITE;
/*!40000 ALTER TABLE `cxml_structureddatadefcont` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_structureddatadefcont` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_structureddatadefinition`
--

DROP TABLE IF EXISTS `cxml_structureddatadefinition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_structureddatadefinition` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xmlId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_SDDEF_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_SDDEF_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_SDDEF_XML` (`xmlId`),
  UNIQUE KEY `UQ_SDDEF_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_SDDEF_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_SDDEF_LOCK` (`lockId`),
  KEY `FK_SDDEF_CONTAINER` (`containerId`),
  KEY `IDX_SDDEF_PATH` (`path`),
  KEY `FK_SDDEF_SITE` (`siteId`),
  CONSTRAINT `FK_SDDEF_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_structureddatadefcont` (`id`),
  CONSTRAINT `FK_SDDEF_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDDEF_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDDEF_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_structureddatadefinition` (`id`),
  CONSTRAINT `FK_SDDEF_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_SDDEF_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_structureddatadefinition` (`id`),
  CONSTRAINT `FK_SDDEF_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_SDDEF_XML` FOREIGN KEY (`xmlId`) REFERENCES `cxml_xml` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_structureddatadefinition`
--

LOCK TABLES `cxml_structureddatadefinition` WRITE;
/*!40000 ALTER TABLE `cxml_structureddatadefinition` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_structureddatadefinition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_systemproperty`
--

DROP TABLE IF EXISTS `cxml_systemproperty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_systemproperty` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SYSPROP_NAME` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_systemproperty`
--

LOCK TABLES `cxml_systemproperty` WRITE;
/*!40000 ALTER TABLE `cxml_systemproperty` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_systemproperty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_target`
--

DROP TABLE IF EXISTS `cxml_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_target` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publishPath` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parentTargetId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `extension` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serializationType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastPublishedBy` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastDatePublished` bigint(20) DEFAULT NULL,
  `timeToPublish` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usesScheduledPublishing` tinyint(4) NOT NULL DEFAULT '0',
  `publishEvery` bigint(20) DEFAULT NULL,
  `publishEveryTimeUnit` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shouldIncludeTargetPath` tinyint(4) NOT NULL DEFAULT '0',
  `baseFolderId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shouldIncludeXMLDeclaration` tinyint(4) NOT NULL DEFAULT '0',
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cssfileId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cssClasses` text COLLATE utf8_unicode_ci,
  `removeBaseFolderFromPubPath` tinyint(4) NOT NULL DEFAULT '0',
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destinationContainerType` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_TARGET_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_TARGET_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_TARGET_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_TARGET_LOCK` (`lockId`),
  UNIQUE KEY `UQ_TARGET_PREVVERSION` (`prevVersionId`),
  KEY `FK_TARGET_BASEFOLDER` (`baseFolderId`),
  KEY `FK_TARGET_CSSFILE` (`cssfileId`),
  KEY `FK_TARGET_PARENT` (`parentTargetId`),
  KEY `IDX_TARGET_PATH` (`path`),
  KEY `FK_TARGET_SITE` (`siteId`),
  KEY `FK_SITEDESTCONTAINER_PARENT` (`containerId`),
  CONSTRAINT `FK_SITEDESTCONTAINER_PARENT` FOREIGN KEY (`containerId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_TARGET_BASEFOLDER` FOREIGN KEY (`baseFolderId`) REFERENCES `cxml_foldercontent` (`id`),
  CONSTRAINT `FK_TARGET_CSSFILE` FOREIGN KEY (`cssfileId`) REFERENCES `cxml_foldercontent` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TARGET_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TARGET_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TARGET_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_TARGET_PARENT` FOREIGN KEY (`parentTargetId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_TARGET_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TARGET_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_TARGET_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_target`
--

LOCK TABLES `cxml_target` WRITE;
/*!40000 ALTER TABLE `cxml_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_transport`
--

DROP TABLE IF EXISTS `cxml_transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_transport` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `transportType` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `directory` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serverName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `userName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `initialDirectory` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isSecure` tinyint(4) DEFAULT NULL,
  `isPassive` tinyint(4) DEFAULT NULL,
  `ftpTransVersion` tinyint(3) unsigned DEFAULT NULL,
  `packetSize` int(11) DEFAULT NULL,
  `foreignSiteId` int(11) DEFAULT NULL,
  `accountId` int(11) DEFAULT NULL,
  `databaseName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_TRANSPORT_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_TRANSPORT_LOCK` (`lockId`),
  UNIQUE KEY `UQ_TRANSPORT_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_TRANSPORT_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_TRANSPORT_PERMISSIONS` (`permissionsId`),
  KEY `FK_TRANSPORT_CONTAINER` (`containerId`),
  KEY `FK_TRANSPORT_PERMISSIONS` (`permissionsId`),
  KEY `IDX_TRANSPORT_PATH` (`path`),
  KEY `FK_TRANSPORT_SITE` (`siteId`),
  CONSTRAINT `FK_TRANSPORT_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_transportcontainer` (`id`),
  CONSTRAINT `FK_TRANSPORT_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TRANSPORT_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_TRANSPORT_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_target` (`id`),
  CONSTRAINT `FK_TRANSPORT_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TRANSPORT_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_transport` (`id`),
  CONSTRAINT `FK_TRANSPORT_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_transport`
--

LOCK TABLES `cxml_transport` WRITE;
/*!40000 ALTER TABLE `cxml_transport` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_transportcontainer`
--

DROP TABLE IF EXISTS `cxml_transportcontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_transportcontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_TRANSPORTCONT_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_TRANSPORTCONT_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_TRANSPORT_CONT_LOCK` (`lockId`),
  UNIQUE KEY `UQ_TRANSPORT_CONT_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_TRANSPORT_CONT_PREVVERSION` (`prevVersionId`),
  KEY `FK_TRANSPORT_CONT_CONTAINER` (`containerId`),
  KEY `IDX_TRANSPORTCONT_PATH` (`path`),
  KEY `FK_TRANSPORT_CONT_SITE` (`siteId`),
  CONSTRAINT `FK_TRANSPORTCONT_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_TRANSPORTCONT_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TRANSPORT_CONT_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_transportcontainer` (`id`),
  CONSTRAINT `FK_TRANSPORT_CONT_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_TRANSPORT_CONT_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_transportcontainer` (`id`),
  CONSTRAINT `FK_TRANSPORT_CONT_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_transportcontainer` (`id`),
  CONSTRAINT `FK_TRANSPORT_CONT_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_transportcontainer`
--

LOCK TABLES `cxml_transportcontainer` WRITE;
/*!40000 ALTER TABLE `cxml_transportcontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_transportcontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_user`
--

DROP TABLE IF EXISTS `cxml_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_user` (
  `userName` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isEnabled` tinyint(4) NOT NULL DEFAULT '1',
  `authMode` int(11) NOT NULL DEFAULT '0',
  `ldapDN` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hash` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `defaultGroup` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `defaultSiteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`userName`),
  KEY `FK_USER_DEFAULTGROUP` (`defaultGroup`),
  KEY `FK_USER_DEFAULTSITE` (`defaultSiteId`),
  CONSTRAINT `FK_USER_DEFAULTGROUP` FOREIGN KEY (`defaultGroup`) REFERENCES `cxml_group` (`name`) ON DELETE SET NULL,
  CONSTRAINT `FK_USER_DEFAULTSITE` FOREIGN KEY (`defaultSiteId`) REFERENCES `cxml_site` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_user`
--

LOCK TABLES `cxml_user` WRITE;
/*!40000 ALTER TABLE `cxml_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_userlexicon`
--

DROP TABLE IF EXISTS `cxml_userlexicon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_userlexicon` (
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `words` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_userlexicon`
--

LOCK TABLES `cxml_userlexicon` WRITE;
/*!40000 ALTER TABLE `cxml_userlexicon` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_userlexicon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflow`
--

DROP TABLE IF EXISTS `cxml_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflow` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `relatedEntityId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relatedEntityType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owner` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startDate` bigint(20) DEFAULT NULL,
  `endDate` bigint(20) DEFAULT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currentStepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstStepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isInitialized` tinyint(4) NOT NULL DEFAULT '0',
  `definitionXML` text COLLATE utf8_unicode_ci,
  `isCompleted` tinyint(4) NOT NULL DEFAULT '0',
  `historyId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expirationWarningSent` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WORKFLOW_HISTORY` (`historyId`),
  UNIQUE KEY `UQ_WORKFLOW_FIRSTSTEP` (`firstStepId`),
  UNIQUE KEY `UQ_WORKFLOW_CURSTEP` (`currentStepId`),
  KEY `IDX_WORKFLOW_END` (`endDate`),
  KEY `IDX_WORKFLOW_OWNER` (`owner`),
  CONSTRAINT `FK_WORKFLOW_CURSTEP` FOREIGN KEY (`currentStepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WORKFLOW_FIRSTSTEP` FOREIGN KEY (`firstStepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WORKFLOW_HISTORY` FOREIGN KEY (`historyId`) REFERENCES `cxml_workflowhistory` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflow`
--

LOCK TABLES `cxml_workflow` WRITE;
/*!40000 ALTER TABLE `cxml_workflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowaction`
--

DROP TABLE IF EXISTS `cxml_workflowaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowaction` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `actionType` int(11) NOT NULL DEFAULT '0',
  `resultStepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isAutomatic` tinyint(4) NOT NULL DEFAULT '0',
  `firstTriggerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `displayName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WFACTION_TRIGGER` (`firstTriggerId`),
  KEY `FK_WFACTION_STEP` (`stepId`),
  KEY `FK_WFACTION_RESULTSTEP` (`resultStepId`),
  CONSTRAINT `FK_WFACTION_RESULTSTEP` FOREIGN KEY (`resultStepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WFACTION_STEP` FOREIGN KEY (`stepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WFACTION_TRIGGER` FOREIGN KEY (`firstTriggerId`) REFERENCES `cxml_workflowtrigger` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowaction`
--

LOCK TABLES `cxml_workflowaction` WRITE;
/*!40000 ALTER TABLE `cxml_workflowaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowdefcontainer`
--

DROP TABLE IF EXISTS `cxml_workflowdefcontainer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowdefcontainer` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `isRoot` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WFDC_PERMISSIONS` (`permissionsId`),
  UNIQUE KEY `UQ_WFDC_LOCK` (`lockId`),
  UNIQUE KEY `UQ_WFDC_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_WFDC_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_WFDC_NEXTVERSION` (`nextVersionId`),
  KEY `FK_WFDC_CONTAINER` (`containerId`),
  KEY `IDX_WFDC_PATH` (`path`),
  KEY `FK_WFDC_SITE` (`siteId`),
  CONSTRAINT `FK_WFDC_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_workflowdefcontainer` (`id`),
  CONSTRAINT `FK_WFDC_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_WFDC_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`),
  CONSTRAINT `FK_WFDC_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_workflowdefcontainer` (`id`),
  CONSTRAINT `FK_WFDC_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_WFDC_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_workflowdefcontainer` (`id`),
  CONSTRAINT `FK_WFDC_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowdefcontainer`
--

LOCK TABLES `cxml_workflowdefcontainer` WRITE;
/*!40000 ALTER TABLE `cxml_workflowdefcontainer` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowdefcontainer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowdefinition`
--

DROP TABLE IF EXISTS `cxml_workflowdefinition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowdefinition` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xmlId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workflowType` int(11) NOT NULL DEFAULT '0',
  `containerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `groups` text COLLATE utf8_unicode_ci,
  `metadataId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `versionDate` bigint(20) DEFAULT NULL,
  `isCurrentVersion` tinyint(4) NOT NULL DEFAULT '1',
  `nextVersionId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `permissionsId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `namingValue` tinyint(4) DEFAULT '0',
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siteId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WFDEF_XML` (`xmlId`),
  UNIQUE KEY `UQ_WFDEF_PREVVERSION` (`prevVersionId`),
  UNIQUE KEY `UQ_WFDEF_METADATA` (`metadataId`),
  UNIQUE KEY `UQ_WFDEF_NEXTVERSION` (`nextVersionId`),
  UNIQUE KEY `UQ_WFDEF_LOCK` (`lockId`),
  UNIQUE KEY `UQ_WFDEF_PERMISSIONS` (`permissionsId`),
  KEY `FK_WFDEF_CONTAINER` (`containerId`),
  KEY `IDX_WFDEF_PATH` (`path`),
  KEY `FK_WFDEF_SITE` (`siteId`),
  CONSTRAINT `FK_WFDEF_CONTAINER` FOREIGN KEY (`containerId`) REFERENCES `cxml_workflowdefcontainer` (`id`),
  CONSTRAINT `FK_WFDEF_LOCK` FOREIGN KEY (`lockId`) REFERENCES `cxml_entitylock` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_WFDEF_METADATA` FOREIGN KEY (`metadataId`) REFERENCES `cxml_entitymetadata` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_WFDEF_NEXTVERSION` FOREIGN KEY (`nextVersionId`) REFERENCES `cxml_workflowdefinition` (`id`),
  CONSTRAINT `FK_WFDEF_PERMISSIONS` FOREIGN KEY (`permissionsId`) REFERENCES `cxml_permissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_WFDEF_PREVVERSION` FOREIGN KEY (`prevVersionId`) REFERENCES `cxml_workflowdefinition` (`id`),
  CONSTRAINT `FK_WFDEF_SITE` FOREIGN KEY (`siteId`) REFERENCES `cxml_site` (`id`),
  CONSTRAINT `FK_WFDEF_XML` FOREIGN KEY (`xmlId`) REFERENCES `cxml_xml` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowdefinition`
--

LOCK TABLES `cxml_workflowdefinition` WRITE;
/*!40000 ALTER TABLE `cxml_workflowdefinition` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowdefinition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowhistory`
--

DROP TABLE IF EXISTS `cxml_workflowhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowhistory` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `who` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `tstamp` bigint(20) NOT NULL DEFAULT '0',
  `sourceStepName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `destStepName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `actionName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextHistoryId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevHistoryId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workflowId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WFHIST_PREVHISTORY` (`prevHistoryId`),
  UNIQUE KEY `UQ_WFHIST_NEXTHISTORY` (`nextHistoryId`),
  KEY `FK_WFHIST_WORKFLOW` (`workflowId`),
  CONSTRAINT `FK_WFHIST_NEXTHISTORY` FOREIGN KEY (`nextHistoryId`) REFERENCES `cxml_workflowhistory` (`id`),
  CONSTRAINT `FK_WFHIST_PREVHISTORY` FOREIGN KEY (`prevHistoryId`) REFERENCES `cxml_workflowhistory` (`id`),
  CONSTRAINT `FK_WFHIST_WORKFLOW` FOREIGN KEY (`workflowId`) REFERENCES `cxml_workflow` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowhistory`
--

LOCK TABLES `cxml_workflowhistory` WRITE;
/*!40000 ALTER TABLE `cxml_workflowhistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowstep`
--

DROP TABLE IF EXISTS `cxml_workflowstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowstep` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextStepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevStepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `workflowId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unorderedStepWorkflowId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `owner` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stepType` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isOrdered` tinyint(4) NOT NULL DEFAULT '0',
  `displayName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startedOn` bigint(20) DEFAULT NULL,
  `finishBy` bigint(20) DEFAULT NULL,
  `maxDurationInSeconds` bigint(20) DEFAULT NULL,
  `expirationWarningSent` tinyint(4) NOT NULL DEFAULT '0',
  `ownerType` int(11) NOT NULL DEFAULT '0',
  `escalationStepId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `escalationDurationInSeconds` bigint(20) DEFAULT NULL,
  `escalateBy` bigint(20) DEFAULT NULL,
  `escalateStepIdentifier` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WFSTEP_NEXTSTEP` (`nextStepId`),
  UNIQUE KEY `UQ_WFSTEP_PREVSTEP` (`prevStepId`),
  KEY `FK_WFSTEP_WORKFLOW` (`workflowId`),
  KEY `FK_WFSTEP_ESCALATIONSTEP` (`escalationStepId`),
  KEY `FK_WFSTEP_UNORDEREDWKFLW` (`unorderedStepWorkflowId`),
  KEY `IDX_WFSTEP_ESCALATEBY` (`escalateBy`),
  KEY `IDX_WFSTEP_OWNER` (`owner`),
  CONSTRAINT `FK_WFSTEP_ESCALATIONSTEP` FOREIGN KEY (`escalationStepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WFSTEP_NEXTSTEP` FOREIGN KEY (`nextStepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WFSTEP_PREVSTEP` FOREIGN KEY (`prevStepId`) REFERENCES `cxml_workflowstep` (`id`),
  CONSTRAINT `FK_WFSTEP_UNORDEREDWKFLW` FOREIGN KEY (`unorderedStepWorkflowId`) REFERENCES `cxml_workflow` (`id`),
  CONSTRAINT `FK_WFSTEP_WORKFLOW` FOREIGN KEY (`workflowId`) REFERENCES `cxml_workflow` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowstep`
--

LOCK TABLES `cxml_workflowstep` WRITE;
/*!40000 ALTER TABLE `cxml_workflowstep` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowstep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowtrigger`
--

DROP TABLE IF EXISTS `cxml_workflowtrigger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowtrigger` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `className` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nextTriggerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prevTriggerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_WFTR_PREVTRIGGER` (`prevTriggerId`),
  UNIQUE KEY `UQ_WFTR_NEXTTRIGGER` (`nextTriggerId`),
  CONSTRAINT `FK_WFTR_NEXTTRIGGER` FOREIGN KEY (`nextTriggerId`) REFERENCES `cxml_workflowtrigger` (`id`),
  CONSTRAINT `FK_WFTR_PREVTRIGGER` FOREIGN KEY (`prevTriggerId`) REFERENCES `cxml_workflowtrigger` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowtrigger`
--

LOCK TABLES `cxml_workflowtrigger` WRITE;
/*!40000 ALTER TABLE `cxml_workflowtrigger` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowtrigger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_workflowtriggerparameter`
--

DROP TABLE IF EXISTS `cxml_workflowtriggerparameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_workflowtriggerparameter` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `triggerId` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_WFTP_TRIGGER` (`triggerId`),
  CONSTRAINT `FK_WFTP_TRIGGER` FOREIGN KEY (`triggerId`) REFERENCES `cxml_workflowtrigger` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_workflowtriggerparameter`
--

LOCK TABLES `cxml_workflowtriggerparameter` WRITE;
/*!40000 ALTER TABLE `cxml_workflowtriggerparameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_workflowtriggerparameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cxml_xml`
--

DROP TABLE IF EXISTS `cxml_xml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cxml_xml` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `xmlData` longtext COLLATE utf8_unicode_ci,
  `version` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cxml_xml`
--

LOCK TABLES `cxml_xml` WRITE;
/*!40000 ALTER TABLE `cxml_xml` DISABLE KEYS */;
/*!40000 ALTER TABLE `cxml_xml` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-11-19 15:30:41
