CREATE TABLE file (
  id INTEGER NOT NULL AUTO_INCREMENT,
  account_id INTEGER NOT NULL DEFAULT 1,
  site_id INTEGER NOT NULL DEFAULT 0,
  cms_id VARCHAR(100) NOT NULL,
  folder_id VARCHAR(100),
  metadata_id INTEGER NOT NULL,
  name VARCHAR(255),
  path VARCHAR(255),
  PRIMARY KEY (id)
)
TYPE = InnoDB;

CREATE TABLE folder (
  id INTEGER NOT NULL AUTO_INCREMENT,
  account_id INTEGER NOT NULL DEFAULT 1,
  site_id INTEGER NOT NULL DEFAULT 0,
  cms_id VARCHAR(100) NOT NULL,
  folder_id VARCHAR(100),
  metadata_id INTEGER NOT NULL,
  name VARCHAR(255),
  path VARCHAR(255),
  PRIMARY KEY(id)
)
TYPE = InnoDB;

CREATE TABLE page (
  id INTEGER NOT NULL AUTO_INCREMENT,
  account_id INTEGER NOT NULL DEFAULT 1,
  site_id INTEGER NOT NULL DEFAULT 0,
  cms_id VARCHAR(100) NOT NULL,
  folder_id VARCHAR(100),
  metadata_id INTEGER NOT NULL,
  name VARCHAR(255),
  path VARCHAR(255),
  content TEXT,
  PRIMARY KEY(id)
)
TYPE = InnoDB;

CREATE TABLE metadata (
  id INTEGER NOT NULL AUTO_INCREMENT, 
  account_id INTEGER NOT NULL DEFAULT 1,
  site_id INTEGER NOT NULL DEFAULT 0,
  display_name VARCHAR(255),
  title VARCHAR(255),
  summary TEXT,
  teaser TEXT,
  keywords TEXT,
  description TEXT,
  author VARCHAR(255),
  review_date DATETIME,
  start_date DATETIME,
  end_date DATETIME,
  last_published_at DATETIME,
  last_published_by VARCHAR(100),
  created_by VARCHAR(255),
  created_at DATETIME,
  updated_by VARCHAR(100),
  updated_at DATETIME,
  PRIMARY KEY(id)
)
TYPE = InnoDB;

CREATE TABLE metadata_custom (
  id INTEGER NOT NULL AUTO_INCREMENT,
  account_id INTEGER NOT NULL DEFAULT 1,
  site_id INTEGER NOT NULL DEFAULT 0,
  file_id INTEGER,
  folder_id INTEGER,
  page_id INTEGER,
  field VARCHAR(255),
  value VARCHAR(255),
  PRIMARY KEY(id)
)
TYPE = InnoDB;
